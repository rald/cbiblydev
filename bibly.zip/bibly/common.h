#ifndef COMMON_H
#define COMMON_H

#define STRING_MAX 65536

#endif
